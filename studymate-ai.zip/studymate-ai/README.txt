StudyMate AI — static website prototype

HOW TO PUBLISH
1. Sign in to https://app.netlify.com/drop
2. Upload the folder named `studymate-ai` or, if prompted for a single archive, upload `studymate-ai.zip`.
3. Wait for Netlify to deploy the site.
4. Copy the public HTTPS URL Netlify gives you (it typically ends in netlify.app).
5. Open that URL in a new tab and test it.
6. Paste the URL into the “Live website” field of your haX.baby submission.

NOTES
- This is a static, browser-only prototype.
- The AI tutor is a demonstration with built-in sample explanations, not a connected AI service.
- Tasks and progress are held in memory and reset when the page is reloaded.
- No server or API key is required.
